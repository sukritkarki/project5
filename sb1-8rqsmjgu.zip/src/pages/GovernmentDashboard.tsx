import React, { useState } from 'react';
import { Shield, MapPin, Clock, CheckCircle, AlertCircle, TrendingUp, Filter, Calendar } from 'lucide-react';
import { useIssues } from '../context/IssueContext';
import { useAuth } from '../context/AuthContext';

const GovernmentDashboard = () => {
  const { issues, updateIssue } = useIssues();
  const { user } = useAuth();
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState('');
  const [sortBy, setSortBy] = useState('newest');

  // Filter issues by jurisdiction (in a real app, this would be based on the official's assigned area)
  const jurisdictionIssues = issues.filter(issue => {
    // For demo purposes, show all issues. In production, filter by official's jurisdiction
    return true;
  });

  const filteredIssues = jurisdictionIssues
    .filter(issue => {
      const matchesStatus = !selectedStatus || issue.status === selectedStatus;
      const matchesSeverity = !selectedSeverity || issue.severity === selectedSeverity;
      return matchesStatus && matchesSeverity;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'severity':
          const severityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
          return severityOrder[b.severity] - severityOrder[a.severity];
        case 'popular':
          return b.upvotes - a.upvotes;
        default:
          return 0;
      }
    });

  const handleStatusUpdate = (issueId: string, newStatus: string) => {
    updateIssue(issueId, { status: newStatus as any });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'text-green-600 bg-green-50 border-green-200';
      case 'in-progress': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'acknowledged': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'pending': return 'text-gray-600 bg-gray-50 border-gray-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'urgent': return 'text-red-600 bg-red-50';
      case 'high': return 'text-orange-600 bg-orange-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(date));
  };

  // Statistics
  const totalIssues = filteredIssues.length;
  const pendingIssues = filteredIssues.filter(i => i.status === 'pending').length;
  const inProgressIssues = filteredIssues.filter(i => i.status === 'in-progress').length;
  const resolvedIssues = filteredIssues.filter(i => i.status === 'resolved').length;
  const urgentIssues = filteredIssues.filter(i => i.severity === 'urgent').length;

  const statsCards = [
    { title: 'Total Issues', value: totalIssues, icon: Shield, color: 'text-blue-600 bg-blue-50' },
    { title: 'Pending', value: pendingIssues, icon: Clock, color: 'text-yellow-600 bg-yellow-50' },
    { title: 'In Progress', value: inProgressIssues, icon: AlertCircle, color: 'text-blue-600 bg-blue-50' },
    { title: 'Resolved', value: resolvedIssues, icon: CheckCircle, color: 'text-green-600 bg-green-50' },
    { title: 'Urgent', value: urgentIssues, icon: TrendingUp, color: 'text-red-600 bg-red-50' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <Shield className="w-8 h-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900">Government Dashboard</h1>
        </div>
        <p className="text-gray-600">Manage and respond to citizen issues in your jurisdiction</p>
        {user?.jurisdiction && (
          <div className="mt-2 flex items-center text-sm text-gray-500">
            <MapPin className="w-4 h-4 mr-1" />
            <span>
              {user.jurisdiction.municipality}, Ward {user.jurisdiction.ward}, {user.jurisdiction.district}
            </span>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        {statsCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-full ${stat.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex items-center space-x-4 mb-4">
          <Filter className="w-5 h-5 text-gray-400" />
          <h3 className="text-lg font-semibold text-gray-900">Filters</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="acknowledged">Acknowledged</option>
            <option value="in-progress">In Progress</option>
            <option value="resolved">Resolved</option>
          </select>

          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Severity</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="newest">Newest First</option>
            <option value="severity">By Severity</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>
      </div>

      {/* Issues List */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            Issues Requiring Attention ({filteredIssues.length})
          </h3>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredIssues.map((issue) => (
            <div key={issue.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h4 className="text-lg font-semibold text-gray-900">{issue.title}</h4>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getSeverityColor(issue.severity)}`}>
                      {issue.severity.toUpperCase()}
                    </span>
                  </div>

                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {formatDate(issue.createdAt)}
                    </span>
                    <span className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {issue.municipality}, Ward {issue.ward}
                    </span>
                    <span className="flex items-center">
                      <TrendingUp className="w-4 h-4 mr-1" />
                      {issue.upvotes} upvotes
                    </span>
                  </div>

                  <p className="text-gray-700 mb-4 line-clamp-2">{issue.description}</p>

                  <div className="flex items-center space-x-3">
                    <span className="text-sm font-medium text-gray-600">Category:</span>
                    <span className="px-2 py-1 bg-blue-50 text-blue-700 text-sm rounded">{issue.category}</span>
                  </div>
                </div>

                <div className="ml-6 flex flex-col items-end space-y-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(issue.status)}`}>
                    {issue.status.replace('-', ' ').toUpperCase()}
                  </span>

                  <div className="flex space-x-2">
                    {issue.status === 'pending' && (
                      <button
                        onClick={() => handleStatusUpdate(issue.id, 'acknowledged')}
                        className="px-3 py-1 bg-yellow-500 text-white text-sm rounded hover:bg-yellow-600 transition-colors"
                      >
                        Acknowledge
                      </button>
                    )}
                    {issue.status === 'acknowledged' && (
                      <button
                        onClick={() => handleStatusUpdate(issue.id, 'in-progress')}
                        className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors"
                      >
                        Start Progress
                      </button>
                    )}
                    {issue.status === 'in-progress' && (
                      <button
                        onClick={() => handleStatusUpdate(issue.id, 'resolved')}
                        className="px-3 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600 transition-colors"
                      >
                        Mark Resolved
                      </button>
                    )}
                    {issue.status === 'resolved' && (
                      <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded flex items-center">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Complete
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {filteredIssues.length === 0 && (
            <div className="p-12 text-center">
              <Shield className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No issues found</h3>
              <p className="text-gray-600">All caught up! No issues match your current filters.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GovernmentDashboard;