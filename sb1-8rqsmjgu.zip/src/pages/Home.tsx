import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, MapPin, Users, TrendingUp, Eye, BarChart3 } from 'lucide-react';

const Home = () => {
  const stats = [
    { label: 'Issues Reported', value: '2,847', icon: FileText, color: 'text-red-600 bg-red-50' },
    { label: 'Issues Resolved', value: '1,923', icon: Users, color: 'text-green-600 bg-green-50' },
    { label: 'Active Users', value: '12,456', icon: TrendingUp, color: 'text-blue-600 bg-blue-50' },
    { label: 'Municipalities', value: '753', icon: MapPin, color: 'text-purple-600 bg-purple-50' },
  ];

  const features = [
    {
      title: 'Report Local Issues',
      description: 'Easily report infrastructure problems, safety concerns, or service issues in your area with photos and precise location data.',
      icon: FileText,
      color: 'text-red-600',
    },
    {
      title: 'Track Progress',
      description: 'Monitor the status of reported issues and see real-time updates from government officials handling your concerns.',
      icon: Eye,
      color: 'text-blue-600',
    },
    {
      title: 'Community Engagement',
      description: 'Upvote important issues, comment with additional information, and collaborate with fellow citizens for better solutions.',
      icon: Users,
      color: 'text-green-600',
    },
    {
      title: 'Data-Driven Insights',
      description: 'Access comprehensive analytics to understand local governance performance and community priorities.',
      icon: BarChart3,
      color: 'text-purple-600',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-red-50 via-white to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-red-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-white text-4xl">🇳🇵</span>
            </div>
            <h1 className="text-5xl font-bold text-gray-900 mb-4">
              Stand with Nepal
            </h1>
            <p className="text-2xl text-red-600 font-semibold mb-2">नागरिक आवाज मञ्च</p>
            <p className="text-xl text-gray-600 mb-8">Citizen Voice Platform</p>
          </div>
          
          <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-12 leading-relaxed">
            Empowering citizens to freely express opinions, report local issues, and suggest improvements. 
            Connecting communities with their representatives for better governance.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/report"
              className="inline-flex items-center px-8 py-4 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors shadow-lg"
            >
              <FileText className="w-5 h-5 mr-2" />
              Report an Issue
            </Link>
            <Link
              to="/issues"
              className="inline-flex items-center px-8 py-4 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-lg"
            >
              <MapPin className="w-5 h-5 mr-2" />
              View Issues
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full ${stat.color} mb-4`}>
                    <Icon className="w-8 h-8" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              How Stand with Nepal Works
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A comprehensive platform designed to bridge the gap between citizens and their representatives
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="flex items-start space-x-4">
                  <div className={`flex-shrink-0 w-12 h-12 rounded-lg bg-white shadow-md flex items-center justify-center ${feature.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-red-600 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Make Your Voice Heard?
          </h2>
          <p className="text-xl text-red-100 mb-8">
            Join thousands of citizens working together to improve their communities
          </p>
          <Link
            to="/report"
            className="inline-flex items-center px-8 py-4 bg-white text-red-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors shadow-lg"
          >
            Get Started Today
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;