import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Calendar, User, TrendingUp, MessageCircle, Send, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { useIssues } from '../context/IssueContext';
import { useAuth } from '../context/AuthContext';

const IssueDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { issues, upvoteIssue, addComment, updateIssue } = useIssues();
  const { userRole } = useAuth();
  const [newComment, setNewComment] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [statusUpdate, setStatusUpdate] = useState('');

  const issue = issues.find(i => i.id === id);

  if (!issue) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Issue Not Found</h1>
          <Link to="/issues" className="text-red-600 hover:text-red-700">
            ← Back to Issues
          </Link>
        </div>
      </div>
    );
  }

  const handleUpvote = () => {
    upvoteIssue(issue.id);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
      addComment(issue.id, {
        author: isAnonymous ? 'Anonymous' : 'Current User',
        content: newComment,
        isAnonymous,
      });
      setNewComment('');
    }
  };

  const handleStatusUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newStatus) {
      updateIssue(issue.id, { 
        status: newStatus as any,
        ...(statusUpdate && { statusMessage: statusUpdate })
      });
      setNewStatus('');
      setStatusUpdate('');
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'urgent': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'text-green-600 bg-green-50';
      case 'in-progress': return 'text-blue-600 bg-blue-50';
      case 'acknowledged': return 'text-yellow-600 bg-yellow-50';
      case 'pending': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'resolved': return <CheckCircle className="w-5 h-5" />;
      case 'in-progress': return <Clock className="w-5 h-5" />;
      case 'acknowledged': return <AlertCircle className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(date));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Button */}
      <Link 
        to="/issues" 
        className="inline-flex items-center text-red-600 hover:text-red-700 mb-6 font-medium"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Issues
      </Link>

      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 mb-3">{issue.title}</h1>
              <div className="flex items-center space-x-6 text-sm text-gray-600 mb-4">
                <span className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  {formatDate(issue.createdAt)}
                </span>
                <span className="flex items-center">
                  <User className="w-4 h-4 mr-2" />
                  {issue.isAnonymous ? 'Anonymous' : 'Verified User'}
                </span>
                <span className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2 text-red-500" />
                  {issue.municipality}, Ward {issue.ward}, {issue.district}
                </span>
              </div>
            </div>
            
            <div className="flex flex-col items-end space-y-3">
              <span className={`px-4 py-2 rounded-full text-sm font-medium border ${getSeverityColor(issue.severity)}`}>
                {issue.severity.toUpperCase()}
              </span>
              <span className={`px-4 py-2 rounded-full text-sm font-medium flex items-center ${getStatusColor(issue.status)}`}>
                {getStatusIcon(issue.status)}
                <span className="ml-2 capitalize">{issue.status.replace('-', ' ')}</span>
              </span>
            </div>
          </div>

          <div className="mb-4">
            <span className="inline-block px-4 py-2 bg-blue-50 text-blue-700 text-sm font-medium rounded-full">
              {issue.category}
            </span>
          </div>

          <div className="flex items-center space-x-6">
            <button
              onClick={handleUpvote}
              className="flex items-center space-x-2 px-4 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors"
            >
              <TrendingUp className="w-4 h-4" />
              <span>{issue.upvotes} Upvotes</span>
            </button>
            <span className="flex items-center space-x-2 text-gray-600">
              <MessageCircle className="w-4 h-4" />
              <span>{issue.comments.length} Comments</span>
            </span>
          </div>
        </div>

        {/* Description */}
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Description</h2>
          <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{issue.description}</p>
        </div>

        {/* Government Action Panel */}
        {userRole === 'official' && (
          <div className="p-6 bg-blue-50 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Government Action Panel</h3>
            <form onSubmit={handleStatusUpdate} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Update Status
                  </label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select new status</option>
                    <option value="acknowledged">Acknowledged</option>
                    <option value="in-progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Status Update Message (Optional)
                </label>
                <textarea
                  value={statusUpdate}
                  onChange={(e) => setStatusUpdate(e.target.value)}
                  rows={3}
                  placeholder="Provide an update on the actions being taken..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <button
                type="submit"
                disabled={!newStatus}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
              >
                Update Status
              </button>
            </form>
          </div>
        )}

        {/* Comments Section */}
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Comments ({issue.comments.length})
          </h2>

          {/* Add Comment Form */}
          <form onSubmit={handleAddComment} className="mb-6 p-4 bg-gray-50 rounded-lg">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add your comment or additional information..."
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
            />
            <div className="flex items-center justify-between mt-3">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                />
                <span className="text-sm text-gray-600">Comment anonymously</span>
              </label>
              <button
                type="submit"
                disabled={!newComment.trim()}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="w-4 h-4" />
                <span>Post Comment</span>
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-4">
            {issue.comments.map((comment) => (
              <div key={comment.id} className="p-4 bg-white border border-gray-200 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <span className="font-medium text-gray-900">
                      {comment.isAnonymous ? 'Anonymous' : comment.author}
                    </span>
                    {comment.isAnonymous && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                        Anonymous
                      </span>
                    )}
                  </div>
                  <span className="text-sm text-gray-500">
                    {formatDate(comment.createdAt)}
                  </span>
                </div>
                <p className="text-gray-700 leading-relaxed">{comment.content}</p>
              </div>
            ))}

            {issue.comments.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No comments yet. Be the first to share your thoughts!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default IssueDetail;