import React from 'react';
import { BarChart3, TrendingUp, Users, CheckCircle, Clock, AlertTriangle, MapPin } from 'lucide-react';
import { useIssues } from '../context/IssueContext';

const Analytics = () => {
  const { issues } = useIssues();

  // Calculate statistics
  const totalIssues = issues.length;
  const resolvedIssues = issues.filter(issue => issue.status === 'resolved').length;
  const pendingIssues = issues.filter(issue => issue.status === 'pending').length;
  const inProgressIssues = issues.filter(issue => issue.status === 'in-progress').length;
  const acknowledgedIssues = issues.filter(issue => issue.status === 'acknowledged').length;

  const resolutionRate = totalIssues > 0 ? Math.round((resolvedIssues / totalIssues) * 100) : 0;

  // Category statistics
  const categoryStats = issues.reduce((acc, issue) => {
    acc[issue.category] = (acc[issue.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Severity statistics
  const severityStats = issues.reduce((acc, issue) => {
    acc[issue.severity] = (acc[issue.severity] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Location statistics
  const locationStats = issues.reduce((acc, issue) => {
    const location = `${issue.district}, ${issue.municipality}`;
    acc[location] = (acc[location] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const statsCards = [
    {
      title: 'Total Issues',
      value: totalIssues,
      icon: BarChart3,
      color: 'text-blue-600 bg-blue-50',
      change: '+12%',
    },
    {
      title: 'Resolution Rate',
      value: `${resolutionRate}%`,
      icon: CheckCircle,
      color: 'text-green-600 bg-green-50',
      change: '+5%',
    },
    {
      title: 'Pending Issues',
      value: pendingIssues,
      icon: Clock,
      color: 'text-yellow-600 bg-yellow-50',
      change: '-3%',
    },
    {
      title: 'High Priority',
      value: severityStats.urgent || 0,
      icon: AlertTriangle,
      color: 'text-red-600 bg-red-50',
      change: '+8%',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600">Comprehensive insights into civic issues and government responsiveness</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statsCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-green-600 mt-1">{stat.change} from last month</p>
                </div>
                <div className={`p-3 rounded-full ${stat.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Status Distribution */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Issue Status Distribution</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Resolved</span>
              <span className="text-sm font-bold text-green-600">{resolvedIssues}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-500 h-2 rounded-full"
                style={{ width: `${totalIssues > 0 ? (resolvedIssues / totalIssues) * 100 : 0}%` }}
              ></div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">In Progress</span>
              <span className="text-sm font-bold text-blue-600">{inProgressIssues}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full"
                style={{ width: `${totalIssues > 0 ? (inProgressIssues / totalIssues) * 100 : 0}%` }}
              ></div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Acknowledged</span>
              <span className="text-sm font-bold text-yellow-600">{acknowledgedIssues}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-yellow-500 h-2 rounded-full"
                style={{ width: `${totalIssues > 0 ? (acknowledgedIssues / totalIssues) * 100 : 0}%` }}
              ></div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Pending</span>
              <span className="text-sm font-bold text-gray-600">{pendingIssues}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gray-500 h-2 rounded-full"
                style={{ width: `${totalIssues > 0 ? (pendingIssues / totalIssues) * 100 : 0}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Severity Distribution */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Severity Levels</h3>
          <div className="space-y-4">
            {Object.entries(severityStats).map(([severity, count]) => {
              const percentage = totalIssues > 0 ? (count / totalIssues) * 100 : 0;
              const colors = {
                urgent: 'bg-red-500 text-red-600',
                high: 'bg-orange-500 text-orange-600',
                medium: 'bg-yellow-500 text-yellow-600',
                low: 'bg-green-500 text-green-600',
              };
              
              return (
                <div key={severity}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-600 capitalize">{severity}</span>
                    <span className={`text-sm font-bold ${colors[severity as keyof typeof colors]?.split(' ')[1]}`}>
                      {count}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${colors[severity as keyof typeof colors]?.split(' ')[0]}`}
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Top Categories */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Issue Categories</h3>
          <div className="space-y-3">
            {Object.entries(categoryStats)
              .sort(([,a], [,b]) => b - a)
              .slice(0, 6)
              .map(([category, count]) => (
                <div key={category} className="flex items-center justify-between py-2">
                  <span className="text-sm text-gray-700 flex-1">{category}</span>
                  <div className="flex items-center space-x-3">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{ width: `${totalIssues > 0 ? (count / totalIssues) * 100 : 0}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-900 w-8 text-right">{count}</span>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Top Locations */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <MapPin className="w-5 h-5 mr-2 text-red-500" />
            Most Active Locations
          </h3>
          <div className="space-y-3">
            {Object.entries(locationStats)
              .sort(([,a], [,b]) => b - a)
              .slice(0, 6)
              .map(([location, count]) => (
                <div key={location} className="flex items-center justify-between py-2">
                  <span className="text-sm text-gray-700 flex-1">{location}</span>
                  <div className="flex items-center space-x-3">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-red-500 h-2 rounded-full"
                        style={{ width: `${totalIssues > 0 ? (count / totalIssues) * 100 : 0}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-900 w-8 text-right">{count}</span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* Government Performance Metrics */}
      <div className="mt-8 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Government Responsiveness</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">72hrs</div>
            <div className="text-sm text-gray-600">Average Response Time</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">85%</div>
            <div className="text-sm text-gray-600">Citizen Satisfaction</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">15 days</div>
            <div className="text-sm text-gray-600">Average Resolution Time</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;