export interface Issue {
  id: string;
  title: string;
  category: string;
  description: string;
  province: string;
  district: string;
  municipality: string;
  ward: string;
  isAnonymous: boolean;
  severity: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'acknowledged' | 'in-progress' | 'resolved';
  createdAt: Date;
  upvotes: number;
  comments: Comment[];
  files: File[];
}

export interface Comment {
  id: string;
  author: string;
  content: string;
  createdAt: Date;
  isAnonymous: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'citizen' | 'official' | 'admin';
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward?: string;
  };
}