import React, { createContext, useContext, useState, ReactNode } from 'react';

type UserRole = 'citizen' | 'official' | 'admin';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward?: string;
  };
}

interface AuthContextType {
  user: User | null;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<UserRole>('citizen');

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock authentication - in real app, this would call an API
    const mockUser: User = {
      id: '1',
      name: 'Demo User',
      email: email,
      role: userRole,
      ...(userRole === 'official' && {
        jurisdiction: {
          province: 'Bagmati Province',
          district: 'Kathmandu',
          municipality: 'Kathmandu Metropolitan City',
          ward: '14',
        }
      })
    };
    
    setUser(mockUser);
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      userRole,
      setUserRole,
      login,
      logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};