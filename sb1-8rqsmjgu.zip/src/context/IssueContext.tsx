import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Issue } from '../types';

interface IssueContextType {
  issues: Issue[];
  addIssue: (issue: Omit<Issue, 'id'>) => void;
  updateIssue: (id: string, updates: Partial<Issue>) => void;
  upvoteIssue: (id: string) => void;
  addComment: (issueId: string, comment: { author: string; content: string; isAnonymous: boolean }) => void;
}

const IssueContext = createContext<IssueContextType | undefined>(undefined);

export const useIssues = () => {
  const context = useContext(IssueContext);
  if (!context) {
    throw new Error('useIssues must be used within an IssueProvider');
  }
  return context;
};

// Sample data
const sampleIssues: Issue[] = [
  {
    id: '1',
    title: 'Potholes on Ring Road causing traffic jams',
    category: 'Road & Transportation',
    description: 'Large potholes near Kalanki intersection are causing severe traffic congestion during rush hours. Multiple vehicles have been damaged, and it poses a safety risk for motorcyclists.',
    province: 'Bagmati Province',
    district: 'Kathmandu',
    municipality: 'Kathmandu Metropolitan City',
    ward: '14',
    isAnonymous: false,
    severity: 'high',
    status: 'acknowledged',
    createdAt: new Date('2024-01-15'),
    upvotes: 142,
    comments: [
      {
        id: '1',
        author: 'Ram Sharma',
        content: 'This is affecting thousands of commuters daily. Immediate action needed!',
        createdAt: new Date('2024-01-16'),
        isAnonymous: false,
      },
      {
        id: '2',
        author: 'Anonymous',
        content: 'My bike was damaged because of these potholes. Very dangerous!',
        createdAt: new Date('2024-01-17'),
        isAnonymous: true,
      },
    ],
    files: [],
  },
  {
    id: '2',
    title: 'Water shortage in Bhaktapur municipality',
    category: 'Water Supply',
    description: 'Residents of ward 5 have been facing acute water shortage for the past two weeks. The local water supply has been disrupted and no alternative arrangements have been made.',
    province: 'Bagmati Province',
    district: 'Bhaktapur',
    municipality: 'Bhaktapur Municipality',
    ward: '5',
    isAnonymous: true,
    severity: 'urgent',
    status: 'in-progress',
    createdAt: new Date('2024-01-20'),
    upvotes: 89,
    comments: [
      {
        id: '3',
        author: 'Sita Devi',
        content: 'We are buying water from tankers. This is not sustainable.',
        createdAt: new Date('2024-01-21'),
        isAnonymous: false,
      },
    ],
    files: [],
  },
  {
    id: '3',
    title: 'Broken streetlights on Durbar Marg',
    category: 'Electricity',
    description: 'Most streetlights along Durbar Marg have been non-functional for over a month, creating safety concerns for pedestrians and vehicles during nighttime.',
    province: 'Bagmati Province',
    district: 'Kathmandu',
    municipality: 'Kathmandu Metropolitan City',
    ward: '1',
    isAnonymous: false,
    severity: 'medium',
    status: 'resolved',
    createdAt: new Date('2024-01-10'),
    upvotes: 67,
    comments: [],
    files: [],
  },
  {
    id: '4',
    title: 'Garbage collection irregular in Pokhara',
    category: 'Waste Management',
    description: 'Garbage collection in our area has become very irregular. Waste is piling up on streets, creating health hazards and attracting stray animals.',
    province: 'Gandaki Province',
    district: 'Kaski',
    municipality: 'Pokhara Metropolitan City',
    ward: '8',
    isAnonymous: false,
    severity: 'high',
    status: 'pending',
    createdAt: new Date('2024-01-25'),
    upvotes: 34,
    comments: [
      {
        id: '4',
        author: 'Krishna Thapa',
        content: 'The smell is becoming unbearable. Please take immediate action.',
        createdAt: new Date('2024-01-26'),
        isAnonymous: false,
      },
    ],
    files: [],
  },
  {
    id: '5',
    title: 'School building needs urgent repairs',
    category: 'Education',
    description: 'The roof of the local primary school is leaking badly during monsoon. Students cannot attend classes properly and there are safety concerns.',
    province: 'Province 1',
    district: 'Jhapa',
    municipality: 'Mechinagar Municipality',
    ward: '3',
    isAnonymous: true,
    severity: 'urgent',
    status: 'acknowledged',
    createdAt: new Date('2024-01-18'),
    upvotes: 156,
    comments: [
      {
        id: '5',
        author: 'Anonymous',
        content: 'Children are our future. This should be the top priority.',
        createdAt: new Date('2024-01-19'),
        isAnonymous: true,
      },
      {
        id: '6',
        author: 'Maya Gurung',
        content: 'As a parent, I am very concerned about my child\'s safety at school.',
        createdAt: new Date('2024-01-20'),
        isAnonymous: false,
      },
    ],
    files: [],
  },
];

export const IssueProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [issues, setIssues] = useState<Issue[]>(sampleIssues);

  const addIssue = (issueData: Omit<Issue, 'id'>) => {
    const newIssue: Issue = {
      ...issueData,
      id: Date.now().toString(),
    };
    setIssues(prev => [newIssue, ...prev]);
  };

  const updateIssue = (id: string, updates: Partial<Issue>) => {
    setIssues(prev => prev.map(issue => 
      issue.id === id ? { ...issue, ...updates } : issue
    ));
  };

  const upvoteIssue = (id: string) => {
    setIssues(prev => prev.map(issue => 
      issue.id === id ? { ...issue, upvotes: issue.upvotes + 1 } : issue
    ));
  };

  const addComment = (issueId: string, commentData: { author: string; content: string; isAnonymous: boolean }) => {
    const newComment = {
      id: Date.now().toString(),
      ...commentData,
      createdAt: new Date(),
    };

    setIssues(prev => prev.map(issue => 
      issue.id === issueId 
        ? { ...issue, comments: [...issue.comments, newComment] }
        : issue
    ));
  };

  return (
    <IssueContext.Provider value={{
      issues,
      addIssue,
      updateIssue,
      upvoteIssue,
      addComment,
    }}>
      {children}
    </IssueContext.Provider>
  );
};