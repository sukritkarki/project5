import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, FileText, Eye, BarChart3, Menu, X, User, Shield, Settings } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const location = useLocation();
  const { user, userRole, setUserRole, logout } = useAuth();

  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Report Issue', href: '/report', icon: FileText },
    { name: 'View Issues', href: '/issues', icon: Eye },
    { name: 'Analytics', href: '/analytics', icon: BarChart3 },
  ];

  const isActive = (path: string) => location.pathname === path;

  const handleRoleChange = (role: 'citizen' | 'official' | 'admin') => {
    setUserRole(role);
    setShowUserMenu(false);
  };

  return (
    <header className="bg-white shadow-lg border-b-4 border-red-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">🇳🇵</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Stand with Nepal</h1>
              <p className="text-xs text-gray-600">नागरिक आवाज मञ्च</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive(item.href)
                      ? 'text-red-600 bg-red-50'
                      : 'text-gray-700 hover:text-red-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
            {userRole === 'official' && (
              <Link
                to="/government"
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive('/government')
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <Shield className="w-4 h-4" />
                <span>Dashboard</span>
              </Link>
            )}
          </nav>

          {/* User Role Selector */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <User className="w-4 h-4" />
              <span className="capitalize text-sm font-medium">{userRole}</span>
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                <button
                  onClick={() => handleRoleChange('citizen')}
                  className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                    userRole === 'citizen' ? 'bg-red-50 text-red-600' : 'text-gray-700'
                  }`}
                >
                  <User className="inline w-4 h-4 mr-2" />
                  Citizen
                </button>
                <button
                  onClick={() => handleRoleChange('official')}
                  className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                    userRole === 'official' ? 'bg-blue-50 text-blue-600' : 'text-gray-700'
                  }`}
                >
                  <Shield className="inline w-4 h-4 mr-2" />
                  Government Official
                </button>
                <button
                  onClick={() => handleRoleChange('admin')}
                  className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                    userRole === 'admin' ? 'bg-purple-50 text-purple-600' : 'text-gray-700'
                  }`}
                >
                  <Settings className="inline w-4 h-4 mr-2" />
                  System Admin
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center space-x-3 px-3 py-3 rounded-md text-base font-medium ${
                    isActive(item.href)
                      ? 'text-red-600 bg-red-50'
                      : 'text-gray-700 hover:text-red-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
            {userRole === 'official' && (
              <Link
                to="/government"
                onClick={() => setIsMenuOpen(false)}
                className={`flex items-center space-x-3 px-3 py-3 rounded-md text-base font-medium ${
                  isActive('/government')
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <Shield className="w-5 h-5" />
                <span>Dashboard</span>
              </Link>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;