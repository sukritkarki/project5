import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, TrendingUp, MessageCircle, User, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Issue } from '../types';

interface IssueCardProps {
  issue: Issue;
}

const IssueCard: React.FC<IssueCardProps> = ({ issue }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'urgent': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'text-green-600 bg-green-50';
      case 'in-progress': return 'text-blue-600 bg-blue-50';
      case 'acknowledged': return 'text-yellow-600 bg-yellow-50';
      case 'pending': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'resolved': return <CheckCircle className="w-4 h-4" />;
      case 'in-progress': return <Clock className="w-4 h-4" />;
      case 'acknowledged': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(new Date(date));
  };

  return (
    <Link to={`/issues/${issue.id}`} className="block">
      <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border-l-4 border-red-600">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
              {issue.title}
            </h3>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {formatDate(issue.createdAt)}
              </span>
              <span className="flex items-center">
                <User className="w-4 h-4 mr-1" />
                {issue.isAnonymous ? 'Anonymous' : 'Verified User'}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col items-end space-y-2">
            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getSeverityColor(issue.severity)}`}>
              {issue.severity.toUpperCase()}
            </span>
            <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center ${getStatusColor(issue.status)}`}>
              {getStatusIcon(issue.status)}
              <span className="ml-1 capitalize">{issue.status.replace('-', ' ')}</span>
            </span>
          </div>
        </div>

        {/* Category */}
        <div className="mb-4">
          <span className="inline-block px-3 py-1 bg-blue-50 text-blue-700 text-sm font-medium rounded-full">
            {issue.category}
          </span>
        </div>

        {/* Description */}
        <p className="text-gray-700 mb-4 line-clamp-3">
          {issue.description}
        </p>

        {/* Location */}
        <div className="flex items-center text-sm text-gray-600 mb-4">
          <MapPin className="w-4 h-4 mr-1 text-red-500" />
          <span>{issue.municipality}, Ward {issue.ward}, {issue.district}</span>
        </div>

        {/* Engagement Stats */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex items-center space-x-4">
            <span className="flex items-center text-sm text-gray-600">
              <TrendingUp className="w-4 h-4 mr-1 text-green-500" />
              {issue.upvotes} upvotes
            </span>
            <span className="flex items-center text-sm text-gray-600">
              <MessageCircle className="w-4 h-4 mr-1 text-blue-500" />
              {issue.comments.length} comments
            </span>
          </div>
          
          <span className="text-sm text-red-600 font-medium hover:text-red-700">
            View Details →
          </span>
        </div>
      </div>
    </Link>
  );
};

export default IssueCard;