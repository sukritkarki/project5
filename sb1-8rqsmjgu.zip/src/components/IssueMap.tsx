import React from 'react';
import { MapPin, TrendingUp, MessageCircle } from 'lucide-react';
import { Issue } from '../types';

interface IssueMapProps {
  issues: Issue[];
}

const IssueMap: React.FC<IssueMapProps> = ({ issues }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  // Simulate map coordinates based on location
  const getCoordinates = (issue: Issue) => {
    // This is a mock implementation - in a real app, you'd use actual geocoding
    const baseCoords = { lat: 27.7172, lng: 85.3240 }; // Kathmandu center
    const offset = Math.random() * 0.1 - 0.05;
    return {
      lat: baseCoords.lat + offset,
      lng: baseCoords.lng + offset
    };
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Map Header */}
      <div className="bg-gray-50 px-6 py-4 border-b">
        <h3 className="text-lg font-semibold text-gray-900">Issue Locations</h3>
        <p className="text-sm text-gray-600">Interactive map showing reported issues across Nepal</p>
      </div>

      {/* Map Container */}
      <div className="relative h-96 bg-gradient-to-br from-green-100 to-blue-100">
        {/* Mock Map Background */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-lg font-semibold text-gray-600 mb-2">Interactive Map View</p>
            <p className="text-sm text-gray-500">
              In production, this would show an interactive map with issue locations
            </p>
          </div>
        </div>

        {/* Issue Pins (Mock positioning) */}
        {issues.slice(0, 10).map((issue, index) => (
          <div
            key={issue.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
            style={{
              left: `${20 + (index % 5) * 15 + Math.random() * 10}%`,
              top: `${30 + Math.floor(index / 5) * 20 + Math.random() * 15}%`,
            }}
          >
            <div className={`w-6 h-6 rounded-full ${getSeverityColor(issue.severity)} border-2 border-white shadow-lg group-hover:scale-110 transition-transform`}>
              <div className="w-full h-full rounded-full animate-ping bg-current opacity-25"></div>
            </div>
            
            {/* Tooltip */}
            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white rounded-lg shadow-lg p-4 w-64 opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
              <h4 className="font-semibold text-gray-900 mb-2 truncate">{issue.title}</h4>
              <p className="text-sm text-gray-600 mb-2">{issue.category}</p>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {issue.upvotes}
                </span>
                <span className="flex items-center">
                  <MessageCircle className="w-3 h-3 mr-1" />
                  {issue.comments.length}
                </span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${getSeverityColor(issue.severity)} text-white`}>
                  {issue.severity}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="bg-gray-50 px-6 py-4 border-t">
        <h4 className="text-sm font-semibold text-gray-900 mb-3">Severity Legend</h4>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-sm text-gray-600">Urgent</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span className="text-sm text-gray-600">High</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span className="text-sm text-gray-600">Medium</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-sm text-gray-600">Low</span>
          </div>
        </div>
      </div>

      {/* Issue List Sidebar */}
      <div className="max-h-64 overflow-y-auto">
        {issues.slice(0, 5).map((issue) => (
          <div key={issue.id} className="px-6 py-3 border-b border-gray-100 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="text-sm font-medium text-gray-900 truncate">{issue.title}</h4>
                <p className="text-xs text-gray-500">{issue.municipality}, Ward {issue.ward}</p>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`w-2 h-2 rounded-full ${getSeverityColor(issue.severity)}`}></span>
                <span className="text-xs text-gray-500">{issue.upvotes} votes</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IssueMap;