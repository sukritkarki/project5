import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Home from './pages/Home';
import ReportIssue from './pages/ReportIssue';
import ViewIssues from './pages/ViewIssues';
import Analytics from './pages/Analytics';
import GovernmentDashboard from './pages/GovernmentDashboard';
import IssueDetail from './pages/IssueDetail';
import { IssueProvider } from './context/IssueContext';
import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <IssueProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Header />
            <main>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/report" element={<ReportIssue />} />
                <Route path="/issues" element={<ViewIssues />} />
                <Route path="/issues/:id" element={<IssueDetail />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/government" element={<GovernmentDashboard />} />
              </Routes>
            </main>
          </div>
        </Router>
      </IssueProvider>
    </AuthProvider>
  );
}

export default App;